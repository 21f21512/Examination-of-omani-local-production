<?php

namespace App\Models;

// Import the base Model class from the Illuminate\Database\Eloquent namespace
use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    // Define which attributes can be mass-assigned
    protected $fillable = ['title', 'slug', 'description', 'photo', 'status'];
}
